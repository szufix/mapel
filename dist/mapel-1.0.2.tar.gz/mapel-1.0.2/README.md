# mapel
map of elections

https://mapel.readthedocs.io/
